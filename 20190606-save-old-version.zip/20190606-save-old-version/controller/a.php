<?php

$a = function_exists("zip_open");
var_dump($a);

