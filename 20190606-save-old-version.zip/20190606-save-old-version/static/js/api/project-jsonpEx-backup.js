var projectApi = {}

JsonpEx.domain = "coderchain.cn"

projectApi.getProjectList = function() {
    var params = {
        action: 'getList'
    };
    return new Promise(function(resolve, reject) {
        console.log('准备发出请求2')
        console.log(JsonpEx.sendData)
        JsonpEx.sendData('/controller/projectController.php', params, function() {
            // <script type="text/javascript"> window.name = 'retInfo = {"retCode":0, "retMsg":"创建项目成功", "oRet":"{\"iCode\":0,\"sMsg\":\"\"}", "sSerialCode":"QFQ_20180718225100_ab715c7d0f2373ebef46e510f3748083"};'</script>
            if (retInfo == null) {
                return alert('没有返回数据，失败!')
            }

            console.log('请求的数据：', retInfo)

            if (retInfo.retCode !== 0) {
                // alert(retInfo.retMsg)
                reject(retInfo.retMsg)
                return;
            }
            var user = retInfo.oRet.user
            var arrProject = retInfo.oRet.projectList

            var res = []

            arrProject.forEach(l => {
                res.push({
                    name: l.name,
                    user: user
                })
            })

            // 进行排序
            res.sort(Util.compare)
            resolve(res)
        })

        console.log('准备发出请求3')
    })

}


projectApi.getAllProjectList = function() {
    return new Promise(function(resolve, reject) {
        $.getScript('https://coderchain.cn/js/projectList.js', function() {
            if (arrProject == null) {
                reject('拉取所有项目列表失败')
                return alert('没有返回数据，失败!')
            }

            console.log('请求的数据：', arrProject)

            // 这里处理一下数据, 弄成扁平化
            var res = []

            arrProject.forEach(r => {
                r.projectList.forEach(l => {
                    res.push({
                        name: l,
                        user: r.name
                    })
                })
            })

            res.sort(Util.compare)
            resolve(res)
        })
    })

}

// 获取项目详情
projectApi.getProjectDetail = function(project, sPath, user) {
    var params = {
        action: 'getDetail',
        sPath: sPath,
        sProjectName: project,
        sUser: user
    };

    return new Promise(function(resolve, reject) {
        JsonpEx.sendData('/controller/projectController.php', params, function() {
            // <script type="text/javascript"> window.name = 'retInfo = {"retCode":0, "retMsg":"创建项目成功", "oRet":"{\"iCode\":0,\"sMsg\":\"\"}", "sSerialCode":"QFQ_20180718225100_ab715c7d0f2373ebef46e510f3748083"};'</script>
            if (retInfo == null) {
                reject()
                return alert('没有返回数据，失败!')
            }

            console.log('拉取项目返回的请求的数据：', retInfo)

            if (retInfo.retCode != 0) {
                // alert(retInfo.retMsg)
                reject(retInfo.retMsg)
                return;
            }

            // window.location = '../user/success-login.html'
            if (!retInfo.oRet) {
                // 并发带来的错误
                return resolve([])
            }
            resolve(retInfo.oRet.oRet)
        })
    })

}

/*
projectApi.createProject = function(projectName) {
    console.log('准备发送请求')
    var params = {
        action: 'create',
        sProjectName: projectName,
        file: formData
    };

    return new Promise(function(resolve, reject) {
        JsonpEx.sendData('/controller/projectController.php', params, function() {
            if (retInfo.retCode != 0) {
                alert(retInfo.retMsg)
                reject(retInfo.retMsg)
                return;
            }

            resolve(retInfo)
        })
    })

}
*/

projectApi.createProject = function(formData) {
    var url = '/controller/projectController.php?action=create'
    return new Promise(function(resolve, reject) {
         $.ajax({
          type: "POST",
          url: url,
          data: formData,
          cache: false,
          processData: false,
          contentType: false,
          success: function (res) {
            console.log('创建项目：', res)
            res = JSON.parse(res)
            console.log('parse之后的结果： ', res)
            if (res.retCode != 0) {
              return reject(res.retMsg)
            }

            resolve(res)
          },
          error: function(err) {
            reject('创建项目失败，请稍后再试')
          }
        });
    })
}

// 删除项目
projectApi.deleteProject = function(sProjectName) {
    var params = {
        action: 'delete',
        sProjectName: sProjectName
    };

    return new Promise(function(resolve, reject) {
        JsonpEx.sendData('/controller/projectController.php', params, function() {
            console.log('删除文件后的数据：', retInfo)
            if (retInfo.retCode !== 0) {
                // alert(retInfo.retMsg)
                return reject(retInfo)
            }

            console.log(retInfo)
            console.log('删除文件夹成功')
            resolve(retInfo)
        })
    })


}

// 创建目录
projectApi.createNewDir = function(sProjectName, sPath) {
    var params = {
        action: 'createDir',
        sPath: sPath,
        sProjectName: sProjectName
    };

    return new Promise(function(resolve, reject) {
        JsonpEx.sendData('/controller/projectController.php', params, function() {
            console.log('创建文件夹后的数据：', retInfo)
            if (retInfo.retCode !== 0) {
                // alert(retInfo.retMsg)
                return reject(retInfo)
            }

            console.log(retInfo)
            // window.location = '../user/success-login.html'
            console.log('创建文件夹成功')
            resolve(retInfo)
        })
    })


}

// 获取文件内容
projectApi.getFileContent = function(hash) {
    var params = {
        action: 'getContent',
        sHash: hash
    };

    return new Promise(function(resolve, reject) {
        JsonpEx.sendData('/controller/fileController.php', params, function() {
            if (retInfo == null) {
                reject()
                return alert('没有返回数据，失败!')
            }

            if (retInfo.retCode !== 0) {
                // alert(retInfo.retMsg)
                reject(retInfo)
                return;
            }

            resolve(retInfo)
        })
    })

}

// 修改文件内容
projectApi.saveFile = function(formData, action) {
    if (action == null) {
        url = "/controller/fileController.php"
    } else {
        url = "/controller/fileController.php?action=" + action
    }
    return new Promise(function(resolve, reject) {
         $.ajax({
          type: "POST",
          url: url,
          data: formData,
          cache: false,
          processData: false,
          contentType: false,
          success: function (res) {
            console.log('保存文件返回的结果：', res)
            res = JSON.parse(res)
            console.log('parse之后的结果： ', res)
            if (res.retCode > 0) {
              reject(res)
            }

            resolve(res)
          },
          error: function(err) {
            reject(err)
          }
        });
    })
}

// 删除文件内容
projectApi.deleteFile = function(sProjectName, sPath) {
    var params = {
        action: 'delete',
        sPath: sPath,
        sProjectName: sProjectName
    };

    return new Promise(function(resolve, reject) {
        JsonpEx.sendData('/controller/fileController.php', params, function() {
            console.log('删除文件后的数据：', retInfo)
            if (retInfo.retCode !== 0) {
                // alert(retInfo.retMsg)
                return reject(retInfo)
            }

            console.log(retInfo)
            console.log('删除文件夹成功')
            resolve(retInfo)
        })
    })


}


// 投票
projectApi.vote= function(sProjectName, sProjectOwner, iSupportCount, sFromUser) {
    var params = {
        action: 'vote',
        sProjectName: sProjectName,
        sProjectOwner: sProjectOwner,
        iSupportCount: iSupportCount,
        sFromUser: sFromUser,
    };

    return new Promise(function(resolve, reject) {
        JsonpEx.sendData('/controller/projectController.php', params, function() {
            console.log('投票后的数据：', retInfo)
            if (retInfo.retCode !== 0) {
                // alert(retInfo.retMsg)
                return reject(retInfo.retMsg)
            }

            console.log('投票成功')
            resolve(retInfo)
        })
    })
}


// 获取投票情况
projectApi.getProjectSupportCount = function(sProjectName, sProjectOwner) {
    var params = {
        action: 'getSupportCount',
        sProjectName: sProjectName,
        sProjectOwner: sProjectOwner
    };

    return new Promise(function(resolve, reject) {
        JsonpEx.sendData('/controller/projectController.php', params, function() {
            console.log('投票数据：', retInfo)
            if (retInfo.retCode !== 0) {
                // alert(retInfo.retMsg)
                return reject(retInfo.retMsg)
            }

            console.log('投票数据：', retInfo.oRet)
            resolve(retInfo.oRet.count)
        })
    })
}
