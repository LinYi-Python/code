// 绑定jquery全局拦截器
$(document).ajaxComplete(function(ev, xhr, settings) {
  var res = xhr.responseText

  try {
    var jsonData = JSON.parse(res)
    if (jsonData.retCode == -10) {
      // 登录失效
      Util.showErrorPanel("登录过期，请重新登录")
      Util.clearUserInfo()
      // Util.clearUserName()
      // Util.clearUserAddr()
      setTimeout(function() {
        window.location.href = "/user/login.html"
        // window.location.href = "https://coderchain.cn/user/login.html"
      }, 2000)
    }
  } catch (e) {}
})

var userApi = {}

userApi.getUserInfo = function() {
  var params = {
    action: "getInfo"
  }

  var paramsStr = decodeURIComponent($.param(params))
  var url = "/dev/controller/exUserController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }
        resolve(res.oRet)
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

userApi.modifyInfo = function(userInfo) {
  var params = {
    action: "update"
  }

  var paramsStr = decodeURIComponent($.param(params))
  var url = "/dev/controller/exUserController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: userInfo,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }
        resolve(res.oRet)
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

userApi.uploadFile = function(formData) {
  var url = "/dev/controller/exUserController.php?action=uploadFile"
  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: formData,
      cache: false,
      processData: false,
      contentType: false,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          return reject(res.retMsg)
        }

        resolve(res.oRet)
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}
