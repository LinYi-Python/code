// 绑定jquery全局拦截器
$(document).ajaxComplete(function(ev, xhr, settings) {
  var res = xhr.responseText

  try {
    var jsonData = JSON.parse(res)
    if (jsonData.retCode == -10) {
      // 登录失效
      Util.showErrorPanel("登录过期，请重新登录")
      Util.clearUserInfo()
      // Util.clearUserName()
      // Util.clearUserAddr()
      setTimeout(function() {
        window.location.href = "/user/login.html"
      }, 2000)
    }
  } catch (e) {}
})

var projectApi = {}

projectApi.getProjectList = function() {
  var params = {
    action: "getList"
  }

  var paramsStr = decodeURIComponent($.param(params))
  // var url = '/controller/projectController.php?' + paramsStr
  var url = "/dev/controller/exProjectController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      success: function(res) {
        res = JSON.parse(res)
        // alert(typeof res)
        // alert(res)
        // res = eval(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        var user = res.oRet.user
        var arrProject = res.oRet.projectList

        var data = []

        arrProject.forEach(l => {
          data.push({
            name: l.name,
            user: user,
            createAt: l.detail && l.detail.createAt ? l.detail.createAt : "",
            projectId:
              l.detail && l.detail.sProjectId ? l.detail.sProjectId : ""
          })
        })

        // 进行排序
        data.sort(Util.compare("name"))
        resolve(data)
      },
      error: function(err) {
        alert("cuowu: ", err)
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

projectApi.getAllProjectList = function() {
  return new Promise(function(resolve, reject) {
    $.ajax({
      url: "https://coderchain.cn/js/projectList.js",
      dataType: "script",
      success: function() {
        if (arrProject == null) {
          reject("拉取所有项目列表失败")
          return
        }

        console.log("请求的数据：", arrProject)

        // 这里处理一下数据, 弄成扁平化
        var res = []

        arrProject.forEach(r => {
          r.projectList.forEach(l => {
            res.push({
              name: l,
              user: r.name
            })
          })
        })
        res.sort(Util.compare("name"))
        resolve(res)
      },
      error: function() {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

// 获取项目详情
projectApi.getProjectDetail = function(project, sPath, user) {
  var params = {
    action: "getDetail"
  }

  var data = {
    sPath: sPath,
    sProjectName: project,
    sUser: user
  }

  var paramsStr = decodeURIComponent($.param(params))
  // var url = '/controller/projectController.php?' + paramsStr
  var url = "/dev/controller/exProjectController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: data,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        resolve(res.oRet)
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

/*
projectApi.createProject = function(projectName) {
    console.log('准备发送请求')
    var params = {
        action: 'create',
        sProjectName: projectName,
        file: formData
    };

    return new Promise(function(resolve, reject) {
        JsonpEx.sendData('/controller/projectController.php', params, function() {
            if (retInfo.retCode != 0) {
                alert(retInfo.retMsg)
                reject(retInfo.retMsg)
                return;
            }

            resolve(retInfo)
        })
    })

}
*/

projectApi.createProject = function(formData) {
  // var url = '/controller/projectController.php?action=create'
  var url = "/dev/controller/exProjectController.php?action=create"
  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: formData,
      cache: false,
      processData: false,
      contentType: false,
      success: function(res) {
        console.log("创建项目：", res)
        res = JSON.parse(res)
        console.log("parse之后的结果： ", res)
        if (res.retCode != 0) {
          return reject(res.retMsg)
        }

        resolve(res)
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

// 删除项目
projectApi.deleteProject = function(sProjectName) {
  var params = {
    action: "delete"
  }

  var data = {
    sProjectName: sProjectName
  }

  var paramsStr = decodeURIComponent($.param(params))
  // var url = '/controller/projectController.php?' + paramsStr
  var url = "/dev/controller/exProjectController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: data,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        resolve()
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

// 代码检测
projectApi.detectProject = function(sProjectId) {
  var params = {
    action: "addDetect"
  }

  var data = {
    sProjectId: sProjectId
  }

  var paramsStr = decodeURIComponent($.param(params))
  // var url = '/dev/controller/exProjectController.php?' + paramsStr
  var url = "/dev/controller/exDetectController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: data,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        resolve(res.oRet)
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

projectApi.getDetectStatus = function(sDetectTaskId) {
  var params = {
    action: "detectStatus"
  }

  var data = {
    sDetectTaskId: sDetectTaskId
  }

  var paramsStr = decodeURIComponent($.param(params))
  // var url = '/dev/controller/exProjectController.php?' + paramsStr
  var url = "/dev/controller/exDetectController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: data,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        resolve(res.oRet)
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}
// 查看检测报告
projectApi.readDetectReport = function(sProjectId) {
  var params = {
    action: "readReport"
  }

  var data = {
    sProjectId: sProjectId
  }

  var paramsStr = decodeURIComponent($.param(params))
  // var url = "/dev/controller/exProjectController.php?" + paramsStr
  var url = "/dev/controller/exDetectController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: data,
      success: function(res) {
        console.log("检测报告：", res)

        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        resolve(res.oRet)
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

projectApi.getDetectTaskIdReport = function(sProjectId) {
  var params = {
    action: "getDetectTaskId"
  }

  var data = {
    sProjectId: sProjectId
  }

  var paramsStr = decodeURIComponent($.param(params))
  var url = "/dev/controller/exDetectController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: data,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        resolve(res.oRet)
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

// 创建目录
projectApi.createNewDir = function(sProjectName, sPath) {
  var params = {
    action: "createDir"
  }

  var data = {
    sPath: sPath,
    sProjectName: sProjectName
  }

  var paramsStr = decodeURIComponent($.param(params))
  // var url = '/controller/projectController.php?' + paramsStr
  var url = "/dev/controller/exProjectController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: data,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        resolve()
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

// 获取文件内容
projectApi.getFileContent = function(hash) {
  var params = {
    action: "getContent"
  }

  var data = {
    sHash: hash
  }

  var paramsStr = decodeURIComponent($.param(params))
  var url = "/controller/fileController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: data,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        resolve(res)
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

// 修改文件内容
projectApi.saveFile = function(formData, action) {
  if (action == null) {
    // url = "/controller/fileController.php"
    url = "/dev/controller/fileController.php?action=upload"
  } else {
    url = "/dev/controller/fileController.php?action=" + action
  }
  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: formData,
      cache: false,
      processData: false,
      contentType: false,
      success: function(res) {
        console.log("保存文件返回的结果：", res)
        res = JSON.parse(res)
        console.log("parse之后的结果： ", res)
        if (res.retCode > 0) {
          reject(res)
        }

        resolve(res)
      },
      error: function(err) {
        reject(err)
      }
    })
  })
}

// 删除文件内容
projectApi.deleteFile = function(sProjectName, sPath) {
  var params = {
    action: "delete"
  }

  var data = {
    sPath: sPath,
    sProjectName: sProjectName
  }

  var paramsStr = decodeURIComponent($.param(params))
  // var url = '/controller/fileController.php?' + paramsStr
  var url = "/dev/controller/fileController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: data,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        resolve()
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

// 投票
projectApi.vote = function(
  sProjectName,
  sProjectOwner,
  iSupportCount,
  sFromUser
) {
  var params = {
    action: "vote"
  }

  var data = {
    sProjectName: sProjectName,
    sProjectOwner: sProjectOwner,
    iSupportCount: iSupportCount,
    sFromUser: sFromUser
  }

  var paramsStr = decodeURIComponent($.param(params))
  var url = "/controller/projectController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: data,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        resolve()
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

// 获取投票情况
projectApi.getProjectSupportCount = function(sProjectName, sProjectOwner) {
  var params = {
    action: "getSupportCount"
  }

  var data = {
    sProjectName: sProjectName,
    sProjectOwner: sProjectOwner
  }

  var paramsStr = decodeURIComponent($.param(params))
  var url = "/controller/projectController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: data,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        resolve(res.oRet.count)
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

// 获取项目的更详细信息
projectApi.getProjectMoreDetail = function(data) {
  var params = {
    action: "getProjectListMoreDetail"
  }

  var data = {
    arrProjectList: data
  }

  var paramsStr = decodeURIComponent($.param(params))
  var url = "/dev/controller/exProjectController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: data,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        resolve(res.oRet)
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}

projectApi.getCategoryList = function(data) {
  var params = {
    action: "getCategory"
  }

  var data = {
    arrProjectList: data
  }

  var paramsStr = decodeURIComponent($.param(params))
  var url = "/dev/controller/exCategoryController.php?" + paramsStr

  return new Promise(function(resolve, reject) {
    $.ajax({
      type: "POST",
      url: url,
      data: data,
      success: function(res) {
        res = JSON.parse(res)
        if (res.retCode != 0) {
          reject(res.retMsg)
          return
        }

        resolve(res.oRet)
      },
      error: function(err) {
        reject("网络繁忙，请重新再试")
      }
    })
  })
}
