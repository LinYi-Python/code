var Util = {}
const USER_INFO_KEY = "__USER__"

Util.parseUrlParams = function() {
  var url = location.search
  var paramObj = {}
  if (url.startsWith("?")) {
    url = url.substring(1)
    urlArr = url.split("&")

    urlArr.forEach(function(u) {
      var a = u.split("=")
      paramObj[a[0]] = a[1] || undefined
    })
  }
  return paramObj
}

Util.showInfoPanel = function(msg) {
  Util.hidePanelsImmediately()
  $("body")
    .append(
      '<div class="alert alert-success alert-panel" role="alert">' +
        msg +
        "</div>"
    )
    .fadeIn()

  setTimeout(function() {
    Util.hidePanels()
  }, 3000)
}

Util.showErrorPanel = function(msg) {
  Util.hidePanelsImmediately()
  $("body")
    .append(
      '<div class="alert alert-danger alert-panel" role="alert">' +
        msg +
        "</div>"
    )
    .fadeIn()

  setTimeout(function() {
    Util.hidePanels()
  }, 3000)
}

Util.hidePanels = function() {
  $(".alert-panel").fadeOut(function() {
    $(this).remove()
  })
}

Util.hidePanelsImmediately = function() {
  $(".alert-panel").remove()
}

// 保存起这个对象
Util.setUserInfo = function(oUserInfo) {
  localStorage.setItem(USER_INFO_KEY, JSON.stringify(oUserInfo))
}

Util.getUserInfo = function() {
  let sUserInfo = localStorage.getItem(USER_INFO_KEY)
  return sUserInfo ? JSON.parse(sUserInfo) : {}
}

Util.clearUserInfo = function() {
  localStorage.removeItem(USER_INFO_KEY)
}

Util.getUserName = function() {
  let oUserInfo = Util.getUserInfo()
  return oUserInfo ? oUserInfo["sUserName"] : ""
}

Util.getUserAddr = function() {
  let oUserInfo = Util.getUserInfo()
  return oUserInfo ? oUserInfo["sWalletAddress"] : ""
}

Util.getUserDisplayName = function() {
  let oUserInfo = Util.getUserInfo()
  return oUserInfo ? oUserInfo["sDisplayName"] : ""
}

// 用户头像
Util.getUserAvatar = function() {
  let oUserInfo = Util.getUserInfo()
  return oUserInfo
    ? "/dev/controller/exUserController.php?action=getImage&sImagePath=" +
        oUserInfo["sAvatar"]
    : ""
}

Util.hightAllBlock = function() {
  $("pre code").each(function(i, block) {
    hljs.highlightBlock(block)
    hljs.initLineNumbersOnLoad()
  })
}

Util.hightBlock = function($block) {
  hljs.highlightBlock($block)
  hljs.initLineNumbersOnLoad()
  console.log("hight line成功")
}

Util.isNumber = function(val) {
  if (!isNaN(val)) {
    return true
  }

  return false
}

Util.compare = function(key) {
  return function(a, b) {
    let value1 = a[key]
    let value2 = b[key]

    value1 = decodeURIComponent(value1).toUpperCase()
    value2 = decodeURIComponent(value2).toUpperCase()

    if (value1 < value2) {
      return -1
    } else if (value1 > value2) {
      return 1
    } else {
      return 0
    }
  }
}

Util.trim = function(val) {
  if (val == null) {
    return ""
  }

  return val.replace(/^[\s]+|[\s]+$/g, "")
}

Util.containsBlank = function(val) {
  return /(\s)/g.test(val)
}

Util.isValidFileName = function(name) {
  if (name == null) {
    return false
  }

  // 不允许的字符 * / \ | ? "
  var reg = /[&`=*/\\?"<>|]+/
  if (reg.test(name)) {
    return false
  }

  return true
}

Util.ERR_FILENAME_MSG = ' & " ` = | / \\ ? * '

Util.isEmail = function(email) {
  var re = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/
  return re.test(email)
}

Util.isID = function(sId) {
  var iSum = 0
  var info = ""
  if (!/^\d{17}(\d|x)$/i.test(sId)) return "你输入的身份证长度或格式错误"
  sId = sId.replace(/x$/i, "a")
  if (aCity[parseInt(sId.substr(0, 2))] == null) return "你的身份证地区非法"
  sBirthday =
    sId.substr(6, 4) +
    "-" +
    Number(sId.substr(10, 2)) +
    "-" +
    Number(sId.substr(12, 2))
  var d = new Date(sBirthday.replace(/-/g, "/"))
  if (
    sBirthday !=
    d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate()
  )
    return "身份证上的出生日期非法"
  for (var i = 17; i >= 0; i--)
    iSum += (Math.pow(2, i) % 11) * parseInt(sId.charAt(17 - i), 11)
  if (iSum % 11 != 1) return "你输入的身份证号非法"
  //aCity[parseInt(sId.substr(0,2))]+","+sBirthday+","+(sId.substr(16,1)%2?"男":"女");//此次还可以判断出输入的身份证号的人性别
  return true
}

Util.isPhone = function(phone) {
  var reg = /^0?1[3|4|5|6|7|8][0-9]\d{8}$/
  return reg.test(phone)
}

// 资源类型
Util.isImage = function(ext) {
  var IMG_EXT_ARR = ["jpg", "jpeg", "gif", "png", "ico"]
  return IMG_EXT_ARR.indexOf(ext.toLowerCase()) > -1
}

Util.isUnSupportedType = function(ext) {
  // 不能上传的文件类型
  var UNSUPPORTED_EXT_ARR = [
    "xlsx",
    "ppt",
    "xls",
    "pptx",
    "war",
    "exe",
    "wav",
    "mp3"
  ]
  return UNSUPPORTED_EXT_ARR.indexOf(ext.toLowerCase()) > -1
}

Util.isUnSupportedPackageType = function(ext) {
  var PACKAGE_ARR = ["gz", "tar"]
  return PACKAGE_ARR.indexOf(ext.toLowerCase()) > -1
}

Util.isResourceType = function(ext) {
  var RESOURCE_EXT_ARR = [
    "jpg",
    "jpeg",
    "gif",
    "png",
    "ico",
    "pdf",
    "doc",
    "docx",
    "woff"
  ]
  return RESOURCE_EXT_ARR.indexOf(ext.toLowerCase()) > -1
}

Util.isPackageType = function(ext) {
  var PACKAGE_ARR = ["gz", "tar", "rar", "zip"]
  return PACKAGE_ARR.indexOf(ext.toLowerCase()) > -1
}

Util.getScrollTop = function() {
  var scrollPos
  if (window.pageYOffset) {
    scrollPos = window.pageYOffset
  } else if (document.compatMode && document.compatMode != "BackCompat") {
    scrollPos = document.documentElement.scrollTop
  } else if (document.body) {
    scrollPos = document.body.scrollTop
  }
  return scrollPos
}

Util.getExtName = function(filename) {
  var res = filename.split(".")
  var ext = ""

  if (res.length > 1) {
    ext = res[res.length - 1].toLowerCase()
  }

  return ext
}

Util.isImage = ext => {
  let imgType = ["jpg", "jpeg", "png", "gif", "ico"]
  return imgType.indexOf(ext.toLowerCase()) > -1
}

// 注册Vue组件，实现代码复用
Vue.component("custom-nav", {
  data: function() {
    return {
      username: "",
      userAvatar: "",
      userToken: "---"
    }
  },
  beforeCreate() {
    if (!Util.getUserDisplayName()) {
      return window.location.replace("/user/login.html")
    }
  },
  created() {
    this.username = Util.getUserDisplayName()
    this.userAvatar = Util.getUserAvatar()
  },
  mounted() {
    this.getToken()
  },
  methods: {
    logout: function(e) {
      e.preventDefault()
      var params = {
        action: "logout"
      }

      var paramsStr = decodeURIComponent($.param(params))
      var url = "/controller/userController.php?" + paramsStr
      $.ajax({
        type: "get",
        url: url,
        success: function(res) {
          res = JSON.parse(res)
          if (res.retCode != 0) {
            // Util.showErrorPanel(res.retMsg)
            return
          }
        },
        error: function(err) {
          // Util.showErrMsg('网络繁忙，请重新再试')
        }
      })

      Util.clearUserInfo()
      // Util.clearUserName()
      // Util.clearUserAddr()
      // Util.clearUserAvatar()
      window.location.replace("../index.html")
    },
    getToken: function() {
      var that = this
      var parameter = {
        action: "getToken"
      }

      var paramsStr = decodeURIComponent($.param(parameter))

      // var url = '/controller/userController.php?' + paramsStr
      var url = "/dev/controller/exUserController.php?" + paramsStr
      $.ajax({
        type: "get",
        url: url,
        success: function(res) {
          res = JSON.parse(res)
          if (res.retCode != 0 || !res.oRet) {
            Util.showErrorPanel("拉取Token失败")
            return
          }

          console.log("获取到的Token: ", res.oRet.dBalance)
          tokenUnit = 1000000000000000000
          that.userToken = parseFloat(
            parseInt(res.oRet.dBalance) / tokenUnit
          ).toFixed(2)
        },
        error: function(err) {
          Util.showErrorPanel("网络繁忙，请重新再试")
        }
      })
    }
  },
  template: `
    <nav class="navbar navbar-default menu">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-menu"
                        aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="./index.html" class="navbar-brand bg-navbar">
                    <!--<img src="https://app.denglu1.com/img/CoderChainLogo500.png" alt="CoderChain" class="logo">-->
                    <img src="../static/images/logo/coderchain-text-ch-white.png" alt="CoderChain" class="logo">
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="navbar-menu">
                <ul class="nav navbar-nav">
                    <!--<li><a href="./index.html" class="link">社区主页</a></li>-->
                    <li><a href="./project-create.html" class="link">创建项目</a></li>
                    <li><a href="./project-index.html" class="link">查看所有项目</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <!-- new layout -->
                    <li class="drop-item">
                       <div class="dropdown">
                        <span class="dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                          <img :src="userAvatar" class="user-avatar"/>
                          <span class="caret"></span>
                        </span>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                          <li><a href="javascript:;" class="disabled">用户：{{username}}</a></li>
                          <li><a href="javascript:;" class="disabled">代币：{{ userToken }} CDB</a></li>
                          <li role="separator" class="divider"></li>
                          <li><a href="./user-setting.html">个人设置</a></li>
                          <li><a href="./project-index.html?type=my" class="link">我的项目</a></li>
                          <li role="separator" class="divider"></li>
                          <li><a href="javascript:void(0)" @click="logout" class="link">退出登录</a></li>
                        </ul>
                      </div>
    </li>
                    
                    <!-- old layout
                    <li><a href="./project-index.html?type=my" class="link">我的项目</a></li>
                    <li>
                        <span>[用户：{{username}}]</span>
                        <span>[代币：{{ userToken }} CDB]</span>
                        <a href="javascript:void(0)" @click="logout" class="link">退出登录</a>
                    </li>
                     -->
                </ul>
            </div>

        </div>
    </nav>
  `
})

const padding = (str, length = 2, fillChar = "0") => {
  str = str.toString()
  let strLength = str.length

  if (strLength >= 2) {
    return str
  }

  return fillChar.repeat(length - strLength) + str
}

const filterFullTime = time => {
  const date = new Date(time)
  let year = date.getFullYear()
  let month = padding(date.getMonth() + 1)
  let day = padding(date.getDate())
  let hour = padding(date.getHours())
  let minute = padding(date.getMinutes())
  let second = padding(date.getSeconds())

  // return year + ' 年 ' + month + ' 月 ' + day + ' 日 ' + hour + ' : ' + minute + ' : ' + second
  return `${year}-${month}-${day} ${hour}:${minute}:${second}`
}

// 代码高亮指令
Vue.directive("highlightA", {
  inserted: function(el) {
    console.log("触发指令")
    let blocks = el.querySelectorAll("pre code")
    for (let i = 0; i < blocks.length; i++) {
      const item = blocks[i]
      hljs.highlightBlock(item)
    }
  }
})

Vue.filter("urlDecode", function(value) {
  return decodeURIComponent(value)
})

Vue.filter("formatTime", function(value) {
  if (!value) {
    return "未知"
  }
  let date = filterFullTime(value * 1000)
  return date
})

//  返回顶部组件
Vue.component("return-top", {
  template: `
    <aside class="aside">
      <div class="return-to-top" title="返回顶部">
          <span class="glyphicon glyphicon-arrow-up" aria-hidden="true"></span>
      </div>
  </aside>
  `,
  mounted() {
    $(window).on("scroll", () => {
      if ($(window).scrollTop() >= 1000) {
        $(".return-to-top").fadeIn()
      } else {
        $(".return-to-top").fadeOut()
      }
    })

    $(".return-to-top").on("click", () => {
      $("html, body").animate({ scrollTop: 0 }, 300)
    })
  }
})
