JsonpEx = {};

JsonpEx.sendData = function (url, postData, getDatafn) {

   document.domain = JsonpEx.domain;

   postData.method_post = "true";

   var state = 0; //标志：0设置代理文件, 1获取数据

   var form = $('<form action="'+ url +'" target="_myiframe" method="post"  id="_postForm" style="display:none"></form>');//创建iframe对象

   for (var x in postData){
      $("<input type='hidden'/>")
      .attr("name", x)
      .attr("value", postData[x])
      .appendTo(form);
   }
 
   var iframe = $('<iframe id="_myiframe" name="_myiframe" style="display:none"></iframe>'); //创建iframe对象

   $("body").append(iframe);
   $("body").append(form);
   form.submit();

   $("#_myiframe").attr("name", "");

   iframe.load(function(){

      if (state === 1) {

         var data = document.getElementById("_myiframe").contentWindow.name;   // 读取数据,返回json格式的字符串
         eval(data);

         $("#_postForm").remove();                      //删除form
         $(this).remove();                             //删除iframe,删除数据
         getDatafn();

      } else if (state === 0) {
         state = 1;
         document.getElementById("_myiframe").contentWindow.location = "/proxy.html";    // 设置的代理文件
      }
   });

}